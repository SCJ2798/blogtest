"use strict";
exports.id = 12;
exports.ids = [12];
exports.modules = {

/***/ 8012:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SA": () => (/* binding */ signUpUser),
/* harmony export */   "pH": () => (/* binding */ loginUser),
/* harmony export */   "zB": () => (/* binding */ checkUser)
/* harmony export */ });
/* harmony import */ var _config_httpConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(327);

async function loginUser({ email , psw  }, onError) {
    const response = await fetch(_config_httpConfig__WEBPACK_IMPORTED_MODULE_0__/* .BASE_URL */ ._ + "user/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email,
            psw
        })
    });
    if (response.ok) {
        return response;
    } else {
        onError(response.status);
    }
}
async function signUpUser({ first_name , last_name , email , psw  }, onError) {
    const response = await fetch(_config_httpConfig__WEBPACK_IMPORTED_MODULE_0__/* .BASE_URL */ ._ + "/user/signup", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            first_name,
            last_name,
            email,
            psw
        })
    });
    if (response.status == 201) {
        return response;
    } else {
        onError(response.status);
    }
}
async function checkUser(token, onError) {
    try {
        const response = await fetch(_config_httpConfig__WEBPACK_IMPORTED_MODULE_0__/* .BASE_URL */ ._ + "/user/checkToken", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "authorization": "Bearer " + token
            }
        });
        if (response.ok) {
            return response;
        } else {
            onError();
        }
    } catch (error) {
        console.log(error);
        onError();
    }
}


/***/ })

};
;