"use strict";
exports.id = 553;
exports.ids = [553];
exports.modules = {

/***/ 327:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ BASE_URL)
/* harmony export */ });
const BASE_URL = process.env.API_BASE_URL || "http://localhost:3000/api/";


/***/ }),

/***/ 2553:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FE": () => (/* binding */ getBlogUsingId),
/* harmony export */   "Ry": () => (/* binding */ getAllBlog),
/* harmony export */   "Vh": () => (/* binding */ createBlog),
/* harmony export */   "X4": () => (/* binding */ deleteBlog),
/* harmony export */   "bb": () => (/* binding */ getBlogUsingUserId),
/* harmony export */   "zZ": () => (/* binding */ updateBlog)
/* harmony export */ });
/* harmony import */ var _config_httpConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(327);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1211);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_1__);


async function getAllBlog(onError) {
    const response = await fetch(_config_httpConfig__WEBPACK_IMPORTED_MODULE_0__/* .BASE_URL */ ._ + "/blog/");
    if (response.status == 200) {
        return response;
    } else {
        onError(response.status);
    }
}
async function getBlogUsingId(blogId, onError) {
    const response = await fetch(_config_httpConfig__WEBPACK_IMPORTED_MODULE_0__/* .BASE_URL */ ._ + "blog/" + blogId);
    if (response.status == 200) {
        return response;
    } else {
        onError(response.status);
    }
}
async function getBlogUsingUserId(userId, onError) {
    const response = await fetch(_config_httpConfig__WEBPACK_IMPORTED_MODULE_0__/* .BASE_URL */ ._ + "blog/user/" + userId);
    if (response.status == 200) {
        return response;
    } else {
        onError(response.status);
    }
}
async function createBlog({ title , body , author_id  }, token, onError) {
    const response = await fetch(_config_httpConfig__WEBPACK_IMPORTED_MODULE_0__/* .BASE_URL */ ._ + "/blog", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "authorization": "Bearer " + token
        },
        body: JSON.stringify({
            title,
            body,
            author_id
        })
    });
    if (response.status == 201) {
        return response;
    } else {
        onError(response.status);
    }
}
async function updateBlog(blogId, { title , body  }, token, onError) {
    const response = await fetch(_config_httpConfig__WEBPACK_IMPORTED_MODULE_0__/* .BASE_URL */ ._ + "/blog/" + blogId, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            "authorization": "Bearer " + token
        },
        body: JSON.stringify({
            title,
            body
        })
    });
    if (response.ok) {
        return response;
    } else {
        onError(response.status);
    }
}
async function deleteBlog(blogId, token, onError) {
    const response = await fetch(_config_httpConfig__WEBPACK_IMPORTED_MODULE_0__/* .BASE_URL */ ._ + "/blog/" + blogId, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
            "authorization": "Bearer " + token
        }
    });
    if (response.ok) {
        return response;
    } else {
        onError(response.status);
    }
}


/***/ })

};
;